import { useState, FormEvent, useRef, useEffect } from 'react';
import clsx from 'clsx';

import { ArrowButton } from 'src/ui/arrow-button';
import { Button } from 'src/ui/button';
import { Select } from 'src/ui/select';
import { Separator } from 'src/ui/separator';
import { Text } from 'src/ui/text';

// Импортируем массивы опций
import {
  fontFamilyOptions,  // (1) Шрифт
  fontColors,         // (2) Цвет шрифта
  backgroundColors,   // (3) Цвет фона
  contentWidthArr,    // (4) Ширина контента
} from 'src/constants/articleProps';

import styles from './ArticleParamsForm.module.scss';

type ArticleParamsFormProps = {
  onApply?: (
    bgColor: string,       // (1) Цвет фона
    fontFamily: string,    // (2) Шрифт
    fontColor: string,     // (3) Цвет шрифта
    fontSize: string,      // (4) Размер шрифта (только абзацы)
    containerWidth: string // (5) Ширина контента
  ) => void;
};

export const ArticleParamsForm = ({ onApply }: ArticleParamsFormProps) => {
  const [isOpen, setIsOpen] = useState(false);
  const asideRef = useRef<HTMLElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        isOpen &&
        asideRef.current &&
        !asideRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleToggle = () => setIsOpen(!isOpen);

  // ---- (1) Шрифт (нулевым считаем fontFamilyOptions[0])
  const [selectedFontFamily, setSelectedFontFamily] = useState(fontFamilyOptions[0]);

  // ---- (2) Цвет шрифта (нулевым считаем fontColors[0])
  const [selectedFontColor, setSelectedFontColor] = useState(fontColors[0]);

  // ---- (3) Размер шрифта (только абзацы): три кнопки, дефолт '18px'
  const [selectedTextSize, setSelectedTextSize] = useState('18px');
  const handleSizeClick = (value: string) => setSelectedTextSize(value);

  // ---- (4) Цвет фона (нулевым считаем backgroundColors[0])
  const [selectedBgColor, setSelectedBgColor] = useState(backgroundColors[0]);

  // ---- (5) Ширина контента (нулевым считаем contentWidthArr[0])
  const [selectedWidth, setSelectedWidth] = useState(contentWidthArr[0]);

  // Нажатие «Применить»
  const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    onApply?.(
      selectedBgColor.value,
      selectedFontFamily.value,
      selectedFontColor.value,
      selectedTextSize,
      selectedWidth.value
    );
  };

  // Нажатие «Сбросить»: возвращаем всё к [0]-му элементу, и «18px» для размера
  const handleReset = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // 1) Сброс локальных состояний к [0]-му элементу
    setSelectedFontFamily(fontFamilyOptions[0]);
    setSelectedFontColor(fontColors[0]);
    setSelectedTextSize('18px');
    setSelectedBgColor(backgroundColors[0]);
    setSelectedWidth(contentWidthArr[0]);

    // 2) Вызываем onApply, чтобы статья тоже сбросилась:
    onApply?.(
      backgroundColors[0].value,  // фон: [0]
      fontFamilyOptions[0].value, // шрифт: [0]
      fontColors[0].value,        // цвет шрифта: [0]
      '18px',                     // размер шрифта
      contentWidthArr[0].value    // ширина
    );
  };

  return (
    <>
      <ArrowButton isOpen={isOpen} onClick={handleToggle} />

      <aside
        ref={asideRef}
        className={clsx(styles.container, {
          [styles.container_open]: isOpen,
        })}
      >
        {/* 
          Вешаем onSubmit на форму (для «Применить»)
          и onReset для «Сбросить» (но кнопка-reset нуждается в preventDefault).
        */}
        <form onSubmit={handleSubmit} onReset={handleReset} className={styles.form}>
          <header className={styles.header}>
            <Text size={31} weight={800} uppercase align='center' family='open-sans'>
              <span className={styles.headerSpan}>Задайте параметры</span>
            </Text>
          </header>

          <div className={styles.fields}>
            {/* 1) ШРИФТ */}
            <div>
              <p className={styles.blockTitle}>Шрифт</p>
              <Select
                options={fontFamilyOptions}
                selected={selectedFontFamily}
                onChange={(option) => setSelectedFontFamily(option)}
              />
            </div>

            {/* 2) Цвет шрифта */}
            <div>
              <p className={styles.blockTitle}>Цвет шрифта</p>
              <Select
                options={fontColors}
                selected={selectedFontColor}
                onChange={(option) => setSelectedFontColor(option)}
              />
            </div>

            {/* 3) Размер шрифта (только абзацы) */}
            <div>
              <p className={styles.blockTitle}>Размер шрифта</p>
              <div className={styles.sizeButtons}>
                <button
                  type='button'
                  className={clsx(styles.sizeButton, {
                    [styles.sizeButtonActive]: selectedTextSize === '18px',
                  })}
                  onClick={() => handleSizeClick('18px')}
                >
                  18 PX
                </button>
                <button
                  type='button'
                  className={clsx(styles.sizeButton, {
                    [styles.sizeButtonActive]: selectedTextSize === '25px',
                  })}
                  onClick={() => handleSizeClick('25px')}
                >
                  25 PX
                </button>
                <button
                  type='button'
                  className={clsx(styles.sizeButton, {
                    [styles.sizeButtonActive]: selectedTextSize === '38px',
                  })}
                  onClick={() => handleSizeClick('38px')}
                >
                  38 PX
                </button>
              </div>
            </div>

            <Separator />

            {/* 4) Цвет фона */}
            <div>
              <p className={styles.blockTitle}>Цвет фона</p>
              <Select
                options={backgroundColors}
                selected={selectedBgColor}
                onChange={(option) => setSelectedBgColor(option)}
              />
            </div>

            {/* 5) Ширина контента */}
            <div>
              <p className={styles.blockTitle}>Ширина контента</p>
              <Select
                options={contentWidthArr}
                selected={selectedWidth}
                onChange={(option) => setSelectedWidth(option)}
              />
            </div>
          </div>

          <div className={styles.bottomContainer}>
            {/* type='reset' => триггер onReset={handleReset} */}
            <Button title='Сбросить' htmlType='reset' type='clear' />
            {/* type='submit' => триггер onSubmit={handleSubmit} */}
            <Button title='Применить' htmlType='submit' type='apply' />
          </div>
        </form>
      </aside>
    </>
  );
};
