import styles from './index.module.scss';

export const Separator = () => {
	return <div className={styles.separator}></div>;
};
