import { createRoot } from 'react-dom/client';
import { StrictMode, CSSProperties, useState } from 'react';
import clsx from 'clsx';

import { Article } from './components/article/Article';
import { ArticleParamsForm } from './components/article-params-form/ArticleParamsForm';
import { defaultArticleState } from './constants/articleProps';

import './styles/index.scss';
import styles from './styles/index.module.scss';

const domNode = document.getElementById('root') as HTMLDivElement;
const root = createRoot(domNode);

const App = () => {
  // 1) Цвет фона
  const [bgColor, setBgColor] = useState(defaultArticleState.backgroundColor.value);

  // 2) Шрифт (включая заголовки)
  const [fontFamily, setFontFamily] = useState(
    defaultArticleState.fontFamilyOption.value
  );

  // 3) Цвет шрифта (включая заголовки)
  const [fontColor, setFontColor] = useState(defaultArticleState.fontColor.value);

  // 4) Размер шрифта (только для «обычного» текста)
  // Обратите внимание, что в SCSS (Text.module.scss) прописано var(--font-size).
  // Поэтому здесь мы будем записывать в '--font-size'.
  const [fontSize, setFontSize] = useState(defaultArticleState.fontSizeOption.value);

  // 5) Ширина контента
  const [containerWidth, setContainerWidth] = useState(
    defaultArticleState.contentWidth.value
  );

  // При нажатии «Применить»
  const handleApply = (
    newBgColor: string,
    newFontFamily: string,
    newFontColor: string,
    newFontSize: string,
    newContainerWidth: string
  ) => {
    setBgColor(newBgColor);
    setFontFamily(newFontFamily);
    setFontColor(newFontColor);
    setFontSize(newFontSize);
    setContainerWidth(newContainerWidth);
  };

  return (
    <main
      className={clsx(styles.main)}
      style={
        {
          // (1) фон
          '--bg-color': bgColor,
          // (2) шрифт
          '--font-family': fontFamily,
          // (3) цвет шрифта
          '--font-color': fontColor,
          // (4) размер шрифта (только обычный текст)
          '--font-size': fontSize, // <-- ВАЖНО: именно --font-size
          // (5) ширина
          '--container-width': containerWidth,
        } as CSSProperties
      }
    >
      <ArticleParamsForm onApply={handleApply} />
      <Article />
    </main>
  );
};

root.render(
  <StrictMode>
    <App />
  </StrictMode>
);
